//
//  AppDelegate.swift
//  Exam3
//
//  Created by hyeoktae kwon on 29/03/2019.
//  Copyright © 2019 hyeoktae kwon. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
    }
    
    /*
     alert 설정하는 거 까먹어서 찾아봄
     label에 unit값 만드는거 결국 못함 '원'
     프레임 만드는거에서 시간이 너무 오래걸림
     내용 동작하는 거는 문제없음
     머리는 기억하지 못해도 찾아서 하면 금방 함
     */
    
}

